﻿
function getlist() {
    helper.getperfun(creategrid);
}